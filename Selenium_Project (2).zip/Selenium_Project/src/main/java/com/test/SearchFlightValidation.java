package com.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;



public class SearchFlightValidation  {
	public WebDriver driver;
	public WebDriverWait wait;
	@BeforeTest
	public void initApp() {
		
		System.setProperty("webdriver.chrome.driver", "F:\\Desktop\\Selenium_Project\\driver\\chromedriver.exe");
		ChromeOptions chromeOptions = new ChromeOptions();
		chromeOptions.setBinary("C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe");
		driver = new ChromeDriver(chromeOptions);
		driver.manage().window().maximize();
		driver.get("https://www.hotwire.com");
	}

	
	@Test
	public void TicketBooking() throws ParseException {
		driver.findElement(By.linkText("Vacations")).click();
		wait = new WebDriverWait(driver, 5);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@class='hw-btn hw-btn-check']"))).click();
		selectLocation();
		selectDates(5, 25); 
		selectTimes(); 
		driver.findElement(By.xpath("//*[@id=\"farefinder-package-search-button\"]")).click(); 
		checkFlightDetails(); 
	}

	@AfterTest
	public void tearDown() {
		driver.quit();
	}
	
private void selectLocation() {
		driver.findElement(By.xpath("//*[@id=\"farefinder-package-origin-location-input\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"farefinder-package-origin-location-input\"]")).sendKeys("NYC");
		wait.until(ExpectedConditions.visibilityOfElementLocated(
				By.xpath("//*[@title='New York, United States of America (NYC - All Airports)']")))
				.click();

		driver.findElement(By.xpath("//*[@id=\"farefinder-package-destination-location-input\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"farefinder-package-destination-location-input\"]")).sendKeys("SFD");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@title='San Francisco, CA, United States of America (SFO-San Francisco Intl.)']"))).click();
	}

private void selectDates(int dept, int ret) throws ParseException  {
		String currDate = driver.findElement(By.xpath("//*[@id=\"farefinder-package-startdate-input\"]"))
				.getAttribute("value");
		String newDeptDate = dateCalculator(currDate, dept);
		driver.findElement(By.xpath("//*[@id=\"farefinder-package-startdate-input\"]")).clear();
		driver.findElement(By.xpath("//*[@id=\"farefinder-package-startdate-input\"]")).sendKeys(newDeptDate);
		String newReturnDate = dateCalculator(currDate, ret);
		driver.findElement(By.xpath("//*[@id=\"farefinder-package-enddate-input\"]")).clear();
		driver.findElement(By.xpath("//*[@id=\"farefinder-package-enddate-input\"]")).sendKeys(newReturnDate);
	}

	private void selectTimes() {
		driver.findElement(By.xpath("//*[@id=\"farefinder-package-pickuptime-input\"]")).click();
		Select deptReturnTime = new Select(
				driver.findElement(By.xpath("//*[@id=\"farefinder-package-pickuptime-input\"]")));
		deptReturnTime.selectByVisibleText("Evening");

		driver.findElement(By.xpath("//*[@id=\"farefinder-package-dropofftime-input\"]")).click();
		deptReturnTime = new Select(driver.findElement(By.xpath("//*[@id=\"farefinder-package-dropofftime-input\"]")));
		deptReturnTime.selectByVisibleText("Morning");
	}

	private void checkFlightDetails() {
		wait = new WebDriverWait(driver, 25);
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//*[@id=\"resultsContainer\"]/section/article")));
		List<WebElement> searchList = driver.findElements(By.xpath("//*[@id=\"resultsContainer\"]/section/article"));
		Assert.assertTrue(searchList.size() >= 1, "Flight details are displayed as expected");
	}
	
	public String dateCalculator(String currentDate, int noOfDays) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		Calendar cal = Calendar.getInstance();
		cal.setTime(sdf.parse(currentDate));
		cal.add(Calendar.DATE, noOfDays);
		currentDate = sdf.format(cal.getTime()); 
		return currentDate;
	}

}
